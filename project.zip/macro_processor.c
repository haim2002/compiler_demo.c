#include <stdio.h>
#include <stdlib.h>
#include "macro_processor.h"
#include "macro_expander.h"
#include "data_structures.h"
#include <string.h>
#include <stdbool.h>
#include "constant_sizes.h"



/*----------------------------------------------------------------------------------------------------------------*/

bool is_macro( char buffer []){ /*detects marco code*/

  return(strstr(buffer, MACRO) && !strstr(buffer, END_OF_MACRO) ); 
}

/*----------------------------------------------------------------------------------------------------------------*/

bool end_of_macro( char buffer []){ /*detects end of macro code*/

  return(strstr(buffer, END_OF_MACRO));

}

/*----------------------------------------------------------------------------------------------------------------*/

char *extract_macro_name(char buffer[], char *name){  /*gets macro name*/

 if(name!=NULL && buffer != NULL){
 
  strcpy(name, strtok(buffer, " "));
  strcpy(name, strtok(NULL, " "));
  }

 return name;
}

/*----------------------------------------------------------------------------------------------------------------*/

/*checking if there is a macro name in a string*/
bool is_name_of_macro(str_node* snode,char buffer []){


  return(snode!=NULL && snode->name!=NULL && strstr(buffer, snode->name));
}


/*----------------------------------------------------------------------------------------------------------------*/

/* detect macro names in a file and store them in a the dedicates viriable of the str_node data structure*/
void detect_macro_names(str_node** snode, str_node* head,FILE *file){

 char *name=(char*)malloc(MAX_ROW_LENGTH * sizeof(char));
 char buffer[MAX_ROW_LENGTH];
  
  while(fgets(buffer, MAX_ROW_LENGTH, file) != NULL){ /*while file hasn't ended*/
  
     if(is_macro(buffer)){ /*if its a macro defenition, store it in new node under data*/
      
         extract_macro_name(buffer,name); /*getting the name of the macro*/
         (*snode)->name= (char*)malloc((strlen(name)+1) *sizeof(char)); /* allocating memory equal to the length of the name+1*/
         strcpy((*snode)->name,name);/*copying the  name to the allocated snode->name*/
         set_next(snode, new_str_node(NULL,NULL)); /*setting the next node and starting the detection of macro again*/
         (*snode)=(*snode)->next;
    }
 
}
/*freeing memory and returning file and snode to the first row/node*/
  rewind(file); 
  (*snode)=head;
  free(name);
}

/*----------------------------------------------------------------------------------------------------------------*/

/*detect macro names and copy them to a dedicated node according to the node's name veriable*/
void assign_macro_data_to_name(str_node** snode, str_node* head,FILE *file){

 char *name=(char*)malloc(MAX_ROW_LENGTH * sizeof(char)); 
 char buffer[MAX_ROW_LENGTH];
  
  while(fgets(buffer, MAX_ROW_LENGTH, file) != NULL){ /*while file hasn't ended*/


      if(is_macro(buffer)){ /*if its a macro defenition*/
         
       extract_macro_name(buffer,name); /*saves macro name into a veriable*/


/*while the node and the node name veriable are not NULL and the name of the macro isn't the same as the name stored in the node*/
        while((*snode)!=NULL && (*snode)->name != NULL && strcmp(name,(*snode)->name)!=0){ 
          
          (*snode)=(*snode)->next; /* move to the next node*/        
          }

      fgets(buffer, MAX_ROW_LENGTH, file); /*moving to the next line to avoid including the declation of the definition in the data veriable*/
      

  if((*snode)!=NULL){

      (*snode)->data = (char*)malloc(1 * sizeof(char));
      (*snode)->data[0] = '\0';
       do{

       /*allocates memory increasingly depending on buffer's size+corrent size and making sure allocated size is not NULL or 0*/      
         (*snode)->data = (char*)realloc((*snode)->data, ((*snode)->data ? strlen((*snode)->data) : 0) + strlen(buffer) + 1);
         strcat((*snode)->data, buffer); /*Concatenating buffers content to the data of the node untill the macro defenition ends*/ 
         fgets(buffer, MAX_ROW_LENGTH, file);
          }while(!end_of_macro(buffer));
      }
  (*snode)=head; /*returning the node to head to start the search for names of macros again*/
  
    }
  }

/*freeing memory and returning file and snode to the first row/node*/
 (*snode)=head;
 rewind(file);
 free(name);

}











