#ifndef CONSTANT_SIZES_H
#define CONSTANT_SIZES_H

#define MEMORY_SIZE 1023 /*the size of assmbler's machine memory*/
#define MAX_ROW_LENGTH 81 /* max length of line with NULL terminator*/
#define MAX_LABEL_LENGTH 31 /*max length of label*/
#define LABEL_INDEX 100 /*starter index of memory*/
#define OPERANDS_COUNT 16 /*number of commands*/
#define REGISTERS_COUNT 8 /*number of registers*/
#define ERROR -1 /*decided value on every time there is error in a given code*/
#define MAX_NUMBER 1023 /*max possible number to be representet by 12 bits*/
#define MIN_NUMBER -512 /*min possible number to be represented by 12 bits*/
#define INSTRUCTION_SIZE 12 /*number of bits in an instruction*/
#define RELOCATABLE_A_R_E 2
#define EXTRN_A_R_E 1

#endif
