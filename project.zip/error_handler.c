#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "error_handler.h"
#include "label_handler.h"
#include "instructions.h"
#include "constant_sizes.h"
#include "data_structures.h"
#include "actions_on_strings.h"
#include "conversions.h"

bool global_error_flag=false; /*extern flag defined in error_handler.h. indication for if a file has errors*/




/*------------------------------------------------------------------------------------------------------------------------------------*/
/* the function deals with error related with labels*/
void label_error_handler(char buffer[],int line,char *unfolded_filename,str_int_node *node){

 char faulty_label_name[MAX_ROW_LENGTH],buffer_to_print[MAX_ROW_LENGTH];
 int buffer_index=0,faulty_label_index=0;
 bool space_flag=false,is_over=false,has_symbols=false;
 str_int_node *head=NULL;
 head=node;

 if(strchr(buffer, ':') != NULL){ /*if there is label definition*/

   while(isspace(buffer[buffer_index])){ /*skip spaces at the start of the line*/
  
     buffer_index++;
     }

    while(buffer[buffer_index] !='\0'){

      faulty_label_name[faulty_label_index]=buffer[buffer_index]; /*build the label name*/

      if(buffer[buffer_index] ==':'){ /*end if label*/

        if(!isspace(buffer[buffer_index+1])){  /*if there are more letters after :*/
     
          strcpy(buffer_to_print,buffer);
          buffer_to_print[strlen(buffer)-1] = '\0'; /*nicer print*/
          printf("error: label definition must end with ':' (%s). line %d. file %s\n",buffer_to_print,line,unfolded_filename);
          global_error_flag=true; 
          }

        faulty_label_name[faulty_label_index]= '\0';
        is_over=true;    /*marks the end of label definition. help to print error once*/     
        }

      if(isspace(buffer[buffer_index])){ /*if label isnt on start of line or label just has space in its definition*/

        space_flag=true;
        }

      if(!isalnum(faulty_label_name[faulty_label_index]) && faulty_label_name[faulty_label_index] != '\0'){ /*if label has chararcters that are not numbers or letters*/

        has_symbols=true;
         
        }

      if(has_symbols && is_over){

        printf("error: label (%s) must contain only numbers and letters. line %d. file %s\n",faulty_label_name,line,unfolded_filename);
        global_error_flag=true; 
         }
      if(space_flag && is_over){

        printf("error: space Spaces are not allowed in label (%s). line %d. file: %s\n",faulty_label_name,line,unfolded_filename);    
        global_error_flag=true; 
        }

      if(!(isalpha(faulty_label_name[0])) && is_over){ /*if the character isnt letter*/

        printf("error: label (%s) must start with a letter. line %d. file: %s\n",faulty_label_name,line,unfolded_filename);  
        global_error_flag=true;
        }

      if(faulty_label_index>MAX_LABEL_LENGTH && is_over){ /*if a label has more characters than allowed*/
           
        printf("error: label (%s) is too long (%d), max length %d. line %d. file: %s\n",faulty_label_name,faulty_label_index, MAX_LABEL_LENGTH,line,unfolded_filename);  
        global_error_flag=true;
        }

      if(is_label(buffer) && is_command(faulty_label_name) && is_over){ /*if a label is command name*/

        printf("error: cant set label (%s) to be an instruction name. line %d. file %s\n",faulty_label_name,line,unfolded_filename);
        global_error_flag=true;   
        }

       if(is_label(buffer) && is_register_name(faulty_label_name) && is_over){ /*if a label is command name*/

        printf("error: cant set label (%s) to be a register name. line %d. file %s\n",faulty_label_name,line,unfolded_filename);
        global_error_flag=true;   
        }    
      
      while (node != NULL && node->name != NULL){

        if (strcmp(node->name,faulty_label_name) == 0) { /*check if label name already exists*/
           
            printf("error: cant set label to (%s). label name alredy been used. line %d. file %s\n",faulty_label_name,line,unfolded_filename);
            global_error_flag=true; 
        }
        node=node->next;
    }
 
       node=head;
      
      if(is_over)/*end loop after label complitly analyzed*/
          break;

      buffer_index++;
      faulty_label_index++;
  }
 } 

}

/*------------------------------------------------------------------------------------------------------------------------------------*/

/* the function deals with error related with commands*/
void command_error_handler(char buffer[],int line,int source,int destination,int command_index,char *unfolded_filename){

 char *command=NULL;
 int temp_index=0;


/*if the line is a command, find the starting index of command*/
if(command_index!=ERROR){

 temp_index = (strstr(buffer, commands_array[command_index])- buffer)-1;
 }

/*if a legal command found with strstr and after the last letter and before the first there are no additional letters, there are no more letters, extract the command using the command index and the aray of commands*/
 if(command_index!=ERROR && isspace(buffer[temp_index+strlen(commands_array[command_index])+1]) && (isspace(buffer[temp_index]) || temp_index == -1) ){
 
   command=(char*)malloc((strlen(commands_array[command_index])+1) * sizeof(char));
   strcpy(command,commands_array[command_index]);
   
   if(source == NO_CALL_TYPE){ /*for every command that needs to have source call type and doesnt have, print error*/

      
     if(strcmp(command,mov) == 0 || strcmp(command,cmp) == 0 || strcmp(command,add) == 0 || strcmp(command,sub) == 0 || strcmp(command,lea) == 0){

       printf("error: missing source address for %s. line %d. file %s\n",command,line,unfolded_filename);
       global_error_flag=true; 
       } 
    }

   if(source != NO_CALL_TYPE){ /*for every command that doesnt need to have source call type have, print error*/

     if(strcmp(command,nott) == 0 || strcmp(command,clr) == 0 || strcmp(command,inc) == 0 || strcmp(command,dec) == 0 || strcmp(command,jmp) == 0 || strcmp(command,bne) ==0 || strcmp(command,red) ==0 
       || strcmp(command,prn) == 0 || strcmp(command,jsr) == 0 || strcmp(command,rts) == 0 || strcmp(command,stop) == 0){

       printf("error: source address unnecessary for %s. line %d. file %s\n",command,line,unfolded_filename);
       global_error_flag=true; 
       }  
     } 

   if(strcmp(command,lea) == 0 && source != CALL_TYPE_REGISTER){ /* lea's source call type must be register. if not, print error*/

     printf("error: source address must be a register for %s. line %d. file %s\n",command,line,unfolded_filename);
     global_error_flag=true; 
     }


   if(destination == NO_CALL_TYPE){ /*for every command that needs to have destination call type and doesnt have, print error*/

     if(strcmp(command,mov) == 0 || strcmp(command,cmp) == 0 || strcmp(command,add) ==0 || strcmp(command,sub) == 0 || strcmp(command,nott) == 0 || strcmp(command,clr) == 0 || strcmp(command,lea) == 0 
       || strcmp(command,inc) == 0 || strcmp(command,dec) == 0 || strcmp(command,jmp) == 0 || strcmp(command,bne) == 0 || strcmp(command,red) == 0 || strcmp(command,prn) == 0 
       || strcmp(command,jsr) == 0){

       printf("error: missing destination address for %s. line %d. file %s\n",command,line,unfolded_filename);
       global_error_flag=true; 
       }
     }



    if(destination == CALL_TYPE_NUMBER){ /*for every command that needs destination call type and doesnt have, print error*/

      if(strcmp(command,mov) == 0 || strcmp(command,add) == 0 || strcmp(command,sub) == 0 || strcmp(command,nott) == 0 || strcmp(command,clr) == 0 || strcmp(command,lea) == 0 || strcmp(command,inc) == 0 
         || strcmp(command,dec) == 0 || strcmp(command,jmp) ==0 || strcmp(command,bne) == 0 || strcmp(command,red) == 0 || strcmp(command,jsr) == 0){

         printf("error: desination address cant be a number for %s. line %d. file %s\n",command,line,unfolded_filename);
         global_error_flag=true; 
         }
       }
  
   if(destination != NO_CALL_TYPE){ /*for every command that has destination call type and doesnt need, print error*/

    if(strcmp(command,rts) == 0 || strcmp(command,stop) == 0){
  
       printf("error: destination address unnecessary for %s. line %d. file %s\n",command,line,unfolded_filename);
       global_error_flag=true; 
       }
    }
   
    if(source == ERROR){ /*unrecognizable source*/

      printf("error: unknown source for %s. line %d. file %s\n",command,line,unfolded_filename);
      global_error_flag=true; 
      }

    if(destination == ERROR){ /*unrecognizable destination*/

      printf("error: unknown destination for %s. line %d. file %s\n",command,line,unfolded_filename);
      global_error_flag=true; 
      }


  free(command);
  }
}
/*------------------------------------------------------------------------------------------------------------------------------------*/

/*checks if the numbers can be defined in 12 bits*/
void value_threshold_handler(int line,int number,char *unfolded_filename){

 if(number > MAX_NUMBER){

   printf("error: value (%d) too high. line %d. file %s\n",number,line,unfolded_filename);
   global_error_flag=true; 
   }

 if(number < MIN_NUMBER){

   printf("error: value (%d) too low. line %d. file %s\n",number,line,unfolded_filename);
   global_error_flag=true; 
   }

}

/*------------------------------------------------------------------------------------------------------------------------------------*/

void data_error_handler(char *array,int line,char *unfolded_filename){

 char *data = NULL,*array_token=NULL;
 int length=0,i=0;
 bool too_many_commas=false;
 

 remove_trailing_spaces(array); 

 while(isspace(array[0])){ /*remove spaces from start of string*/

   array++;
   }


 array_token=(char*)malloc((strlen(array)+1) * sizeof(char)); /*allocates memory for copying memory of array in order to avoide changing array with strok in error description*/
 strcpy(array_token,array);
 data= strtok(array_token,","); /*check every value in .data and determine if legal*/
 length = strlen(array);

 if(array[length-1] == ','){

   printf("error: cant have \',\' at the end of .data definition \"%s\". line: %d, file: %s",array,line,unfolded_filename);
   }

 if(array[0] == ','){

   printf("error: cant have \',\' at the start of .data definition \"%s\". line: %d, file: %s",array,line,unfolded_filename);
   }

 for (i = 0; i < length - 1; i++){ /*check for consecutive commas*/

   if(array[i] == ',' && array[i + 1] == ','){

     too_many_commas = true; 
     }
   }
 
 if(too_many_commas){

   printf("error: too many \',\' in data definition %s. line: %d, file: %s",array,line,unfolded_filename);
   }
  

 while(data !=NULL){

   if(string_to_ptr_int(data) == NULL){

     printf("error: only numbers allowed in .data declaration %s. line: %d, file: %s\n",array,line,unfolded_filename);
     }

   else{

     value_threshold_handler(line,(*string_to_ptr_int(data)),unfolded_filename);
     }
   
    data= strtok(NULL,",");
    }

}


/*------------------------------------------------------------------------------------------------------------------------------------*/



/*deals with generic line errors and uknown commands*/ 
void line_syntax_handler(char buffer[],int line,char *unfolded_filename){

 int validator_index=0,buffer_index=0;
 char validator[MAX_ROW_LENGTH],print_buffer[MAX_ROW_LENGTH];
 bool label=false,command=false,string=false,data=false,unknown=false;


 if(string_is_empty(buffer) || string_is_spaces(buffer)){/*if the string is empty, there are no syntax error*/

   return;
   }



 while(buffer[buffer_index] !='\0'){




   while(isspace(buffer[buffer_index]) && buffer[buffer_index] !='\0'){ /*skip spaces at the start of a line*/

     buffer_index++;
   }

   while(!isspace(buffer[buffer_index]) && buffer[buffer_index] !='\0'){ /*build instruction from letters while no spaces detected*/

     validator[validator_index] = buffer[buffer_index];
     buffer_index++;
     validator_index++;
     }

    validator[validator_index] = '\0';   

    /*if the built instruction is command, command error handler will deal with any error after command detected*/
    if(is_command(validator)){
  
      command=true;
      break;
      }

   else if(is_label(validator)){ 
  
      label=true;
      }
   /*if the built instruction is string definition, string_line_extraction will deal with any error after string_definition detected*/
   else if(is_string_definition(validator)){

      string=true;
      break;
      }
   /*if the built instruction is data definition, data_error_handler will deal with any error after string_definition detected*/
   else if(is_data_definition(validator)){ 

      data=true;
      break;
      }
   /*if the built instruction extrn_definition, lable_error_handler will deal with any error after extrn_definition detected*/
   else if(is_extrn_definition(validator)){

      break;
      }
   /*if the built instruction entry_definition, lable_error_handler will deal with any error after entry_definition detected*/
   else if(is_entry_definition(validator)){

      break;
      }

   else{

     unknown=true;
     }

    strcpy(validator, "");
    validator_index=0;
    buffer_index++;
    }

strcpy(print_buffer,buffer);

 print_buffer[strlen(print_buffer)-1]='\0';   /*remove /n for nicer print*/

 if(label && has_extrn_definition(buffer)){ /*if line has extrn definition and label definition*/

   printf("error: can't define label and extern label at the same line \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }

 if(label && has_entry_definition(buffer)){ /*if line has entry definition and label definition*/

   printf("error: can't define label and entry label at the same line \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }

 if(has_extrn_definition(buffer) && has_entry_definition(buffer)){ /*if line has extrn definition and entry definition*/

   printf("error: can't define extern and entry label at the same line \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }
   
 if(label && !command && !data && !string){ /*if label defined by itself*/

   printf("error: can't define label without command or veriable decleration \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }

  if(has_command(buffer) && has_data_definition(buffer)){ /*if line has command and data definitions*/

   printf("error: can't have command and data decleration at the same line \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }

  if(has_command(buffer) && has_string_definition(buffer)){ /*if line has command and string definitions*/

   printf("error: can't have command and string decleration at the same line \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }

  if(has_string_definition(buffer) && has_data_definition(buffer)){ /*if line has data and string definitions*/

   printf("error: can't have data and string decleration at the same line \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }

 if(unknown){ /*if couldnt associate validator to a known command or instruction*/ 

   printf("error: unknown command \"%s\". line %d. file %s\n",print_buffer,line,unfolded_filename);
   global_error_flag=true;
   }
}
     
     




void memory_error_handler(int IC,int DC,char *unfolded_filename){

 if(IC+DC > MEMORY_SIZE){ /*if there is more memory used than system allowes*/

   printf("error: out of memory. file %s\n",unfolded_filename);
   global_error_flag=true;
   }
}

   









  
  















