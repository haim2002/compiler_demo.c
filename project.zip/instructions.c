#include <stdio.h>
#include "instructions.h"
#include <string.h>
#include "constant_sizes.h"
#include <ctype.h>
#include "conversions.h"
#include "actions_on_strings.h"
#include <stdlib.h>
#include "error_handler.h"

 int IC=0;
 int DC=0;

const char mov[] = "mov";
const char cmp[] = "cmp";
const char add[] = "add";
const char sub[] = "sub";
const char nott[] = "not";
const char clr[] = "clr";
const char lea[] = "lea";
const char inc[] = "inc";
const char dec[] = "dec";
const char jmp[] = "jmp";
const char bne[] = "bne";
const char red[] = "red";
const char prn[] = "prn";
const char jsr[] = "jsr";
const char rts[] = "rts";
const char stop[] = "stop";

/*-----------------------------*/
const char r0[] = "@r0";
const char r1[] = "@r1";
const char r2[] = "@r2";
const char r3[] = "@r3";
const char r4[] = "@r4";
const char r5[] = "@r5";
const char r6[] = "@r6";
const char r7[] = "@r7";
/*-----------------------------*/


/*array of all existing commands*/
const char *commands_array[] = {
 
 "mov",
 "cmp",
 "add",
 "sub",
 "not",
 "clr",
 "lea",
 "inc",
 "dec",
 "jmp",
 "bne",
 "red",
 "prn",
 "jsr",
 "rts",
 "stop"
};

/*-----------------------------*/

/*array of all existing registers*/
const char *registers[] = {
    "@r0",
    "@r1",
    "@r2",
    "@r3",
    "@r4",
    "@r5",
    "@r6",
    "@r7"
};
/*-----------------------------*/
/*array of all existing register names*/
const char *register_names[] = {
    "r0",
    "r1",
    "r2",
    "r3",
    "r4",
    "r5",
    "r6",
    "r7"
};
/*-----------------------------------*/




/*giving commands representation in numbers*/
int command_to_number(const char command[]){

 if (strcmp(command, mov) == 0){
      
   return 0;
   }

 if (strcmp(command, cmp) == 0){
        
   return 1;
   }

 if (strcmp(command, add) == 0){
 
   return 2;
   }

 if (strcmp(command, sub) == 0){
   
   return 3;                     
   }
 
 if (strcmp(command, nott) == 0){
     
   return 4;
   }
   
 if (strcmp(command, clr) == 0){
        
   return 5;
   }

 if (strcmp(command, lea) == 0){    

   return 6;
   }

 if (strcmp(command, inc) == 0){

   return 7;
   }

 if (strcmp(command, dec) == 0){
   
   return 8;
   }

 if (strcmp(command, jmp) == 0){
       
   return 9;
   }

 if (strcmp(command, bne) == 0){
 
   return 10;
   }

 if (strcmp(command, red) == 0){
 
   return 11;
   }

 if (strcmp(command, prn) == 0){
        
   return 12;
   }

  if (strcmp(command, jsr) == 0){
     
    return 13;
    }

  if (strcmp(command, rts) == 0){
  
    return 14;
    }

  if (strcmp(command, stop) == 0){
        
    return 15;
    }


return ERROR;
}


/*----------------------------------------------------------------------*/

/*check if a string is command name*/
bool is_command(char buffer[]) {
 
int i = 0;  

   for (i = 0; i <OPERANDS_COUNT; i++){
       
       if (strcmp(buffer, commands_array[i]) == 0){
              
          return true; 
        }
    }
    return false; 
}
/*----------------------------------------------------------------------*/

/*check if a string has command name in it*/
bool has_command(char buffer[]) {
 
int i = 0;
  
   for (i = 0; i <OPERANDS_COUNT; i++){
       
       if (strstr(buffer, commands_array[i]) != NULL){
              
          return true; 
        }
    }
    return false; 
}

/*----------------------------------------------------------------------*/

/*check if a string is a register*/
bool is_register( char str[]) {
    
 int i = 0;

   for (i = 0; i < REGISTERS_COUNT; i++) {
        if (strcmp(registers[i], str) == 0) {
            return true;
        }
    }
    return false;
}
/*----------------------------------------------------------------------*/

/*check if a string is register's name*/
bool is_register_name( char str[]) {
    
 int i = 0;

   for (i = 0; i < REGISTERS_COUNT; i++) {
        if (strcmp(register_names[i], str) == 0) {
            return true;
        }
    }
    return false;
}
/*----------------------------------------------------------------------*/


/*gives every register value of their index*/
int register_to_num(char reg[]){

 if (strcmp(reg, r0) == 0){

    return 0;
    }

 if (strcmp(reg, r1) == 0){

    return 1;
    }

 if (strcmp(reg, r2) == 0){

    return 2;
    }

 if (strcmp(reg, r3) == 0){

    return 3;
    }

 if (strcmp(reg, r4) == 0){

    return 4;
    }

 if (strcmp(reg, r5) == 0){

    return 5;
    }

 if (strcmp(reg, r6) == 0){

    return 6;
    }

 if (strcmp(reg, r7) == 0){

    return 7;
    }

return ERROR;
}

/*------------------------------------------------------------------------------------------------------------------------------*/

 /*check if string has .data*/
 bool has_data_definition(char buffer[]){

  return strstr(buffer,".data") != NULL;
  }

/*------------------------------------------------------------------------------------------------------------------------------*/

 /*check if string is .data*/
 bool is_data_definition(char buffer[]){

  return strcmp(buffer,".data") == 0;
  }
/*------------------------------------------------------------------------------------------------------------------------------*/

 /*check if string is .string*/
 bool is_string_definition(char buffer[]){

  return strcmp(buffer,".string") == 0;
  }
/*------------------------------------------------------------------------------------------------------------------------------*/

 /*check if string has .string*/
 bool has_string_definition(char buffer[]){

  return strstr(buffer,".string") != NULL;
  }

/*------------------------------------------------------------------------------------------------------------------------------*/
 /*check if string is .extern*/
 bool is_extrn_definition(char buffer[]){
 
  return strcmp(buffer,".extern") == 0;
  }

/*------------------------------------------------------------------------------------------------------------------------------*/

 /*check if string has .extern*/
 bool has_extrn_definition(char buffer[]){
 
  return strstr(buffer,".extern") != NULL;
  }
/*------------------------------------------------------------------------------------------------------------------------------*/

 /*check if string is .entry*/
 bool is_entry_definition(char buffer[]){
 
  return strcmp(buffer,".entry") == 0;
  }

/*------------------------------------------------------------------------------------------------------------------------------*/
 /*check if string has .entry*/
 bool has_entry_definition(char buffer[]){
 
  return strstr(buffer,".entry") != NULL;
  }

/*------------------------------------------------------------------------------------------------------------------------------*/


/*decides which command is in the current line, than sends it to command_to_binary*/
int op_type_decision(char buffer[],int *command_index,int *source_value,int *destination_value,int *source,int *destination,char *source_lable_name,char *destination_label_name){


 int i=0,index=0;
 char *char_index=NULL;
 


   for(i=0; i<OPERANDS_COUNT; i++){

     if(strstr(buffer,commands_array[i])!=NULL){ /*determine which command it is*/

       *command_index=i; /*save commnad index*/
       char_index=strstr(buffer,commands_array[i]); /*save index of appearance in buffer*/
       index= char_index-buffer+strlen(commands_array[i]); /*index of end of command name*/      
       break;
       }
     }

  if(char_index!=NULL){ /*if command found*/

   return command_to_binary(buffer,commands_array[*command_index],index,source_value,destination_value,source,destination,source_lable_name,destination_label_name); /*send details to further procces*/
   }
/*if no command found set all error for knowing its not a command line or at least not a valid one*/
  *command_index=ERROR; 
   return ERROR;  
}

/*------------------------------------------------------------------------------------------------------------------------------*/

/*sends complete first command line to be converted to binary*/
int command_to_binary(char buffer[], const char command[],int index,int *source_value,int *destination_value,int *source,int *destination,char *source_lable_name,char *destination_label_name){

 int command_code=0;
 
 command_code=command_to_number(command); /*getting command value*/
 *source=function_call_type_source(buffer,index,source_value,source_lable_name); /*getting source details*/
 *destination=function_call_type_destination(buffer,index,destination_value,destination_label_name);  /*getting destination details*/ 

 return instruction_command_line_to_binary(*source,command_code,*destination);/*send details to be converted to binary code*/                       
}

/*------------------------------------------------------------------------------------------------------------------------------*/

/*decided the type and value of the source of command line*/
int function_call_type_source(char buffer[],int index,int *source_value,char *source_label_name){


 int i=0,temp_index;
 char source[MAX_ROW_LENGTH];
 temp_index=index;
 
 if(strstr(buffer,",")==NULL){ /*if there is no comma, there is only destination or no call type at all*/

   return NO_CALL_TYPE;
   }

 if(temp_index<strlen(buffer)){

   while(buffer[temp_index]!='\0' && isspace(buffer[temp_index])){ /*skip spaces*/
   
      temp_index++;
      }

   while(buffer[temp_index]!='\0' &&  buffer[temp_index] !=','){ /*between command and comma lies the source*/

     source[i]=buffer[temp_index];
     i++;
     temp_index++;
     }

   source[i]='\0';
   remove_trailing_spaces(source);



   if(string_to_ptr_int(source)!=NULL){ /*if string can be converted fully to numbers, therefore he is a number*/

     *source_value=*(string_to_ptr_int(source)); /*the value is the nubmer itself but in int*/
     return CALL_TYPE_NUMBER;
     }

   if(is_register(source)){ /*if source is register, the value is the code assainged to the register*/
 
     *source_value=register_to_num(source);
     return CALL_TYPE_REGISTER;
     }  
  
   /*if the type is not number or register and there is a source, assume its a label*/
   if(!string_is_empty(source) && !string_is_spaces(source) && isalpha(source[0]) && !string_has_space(source)){ 

    strcpy(source_label_name,source); /*value shall be the name of the label for easier search later in the table of labels*/
     return CALL_TYPE_LABEL;
     }


 /*no source type*/
   if(string_is_empty(source) || string_is_spaces(source)){

     return NO_CALL_TYPE;
     }
  }

 return ERROR;
}
/*------------------------------------------------------------------------------------------------------------------------------*/
       
/*decided the type and value of the destination of command line*/      
int function_call_type_destination(char buffer[],int index,int *destination_value, char *destination_label_name){


 int i=0,temp_index=0;
 char destination[MAX_ROW_LENGTH];
 temp_index=index;

 if(temp_index<strlen(buffer)){

   if(strstr(buffer,",")!=NULL){/* if there is comma, there most be source and destination. going to the index of after comma wil guarantee space or first char of destination*/
   
     temp_index=strstr(buffer, ",")-buffer+1;
     }

   while(buffer[temp_index] !='\0' && isspace(buffer[temp_index])){/*skip space until reaching first character of destination*/
   
     temp_index++;
     }

   while(buffer[temp_index] !='\0'){

     destination[i]=buffer[temp_index];
     i++;
     temp_index++;
     }

   destination[i]='\0';
   remove_trailing_spaces(destination);


   if(string_to_ptr_int(destination) != NULL){ /*if string can be converted fully to numbers, therefore he is a number*/

      *destination_value=*(string_to_ptr_int(destination));
      return CALL_TYPE_NUMBER;
      }

   if(is_register(destination)){ /*if destination is register, the value is the code assainged to the register*/
 
     *destination_value=register_to_num(destination);
     return CALL_TYPE_REGISTER;
    }  

  /*if the type is not number or register and there is a destination, assume its a label*/
   if(!string_is_empty(destination) && !string_is_spaces(destination) && isalpha(destination[0]) && !string_has_space(destination)){

     strcpy(destination_label_name,destination);
     return CALL_TYPE_LABEL;
     }

   if(string_is_empty(destination) || string_is_spaces(destination)){

     return NO_CALL_TYPE;
     }
  }
 

 return ERROR;
}

/*------------------------------------------------------------------------------------------------------------------------------*/

/*the function extract all .data and .string, puts them into a string and sends them to be converted to binary and reconstructed to whole array of strings*/
char **data_line_extraction(char buffer[],int *data_length,int line, char *unfolded_filename){

 int temp_index=0,array_index=0;
 char *array=NULL;

 if(has_data_definition(buffer)){
 
   temp_index=strstr(buffer,".data")-buffer+strlen(".data"); /*the index of the character after the a in .data*/
   array = (char*)malloc((strlen(buffer) - temp_index + 1) *sizeof(char)); /*allocate memory for array in size of the data line - .data +null terminator*/

     while(buffer[temp_index]!='\0'){ 

       array[array_index]=buffer[temp_index]; /*save data in array*/
       array_index++;
       temp_index++;
       }
   array[array_index]='\0';

   return data_to_binary(array,data_length,line,unfolded_filename);
   }


 if(has_string_definition(buffer)){
 
   temp_index=strstr(buffer,".string")-buffer+strlen(".string"); /*the index of the character after the g in .string*/
 
   
   array = (char*)malloc((strlen(buffer) - temp_index + 1) *sizeof(char)); /*allocate memory for array in size of the string line - .string +null terminator*/

     while(buffer[temp_index]!='\0' && isspace(buffer[temp_index])){ /*skip spaces*/

       temp_index++;
       }

     while(buffer[temp_index]!='\0'){

       array[array_index]=buffer[temp_index]; /*copy the string to array*/
       array_index++;
       temp_index++;
       }

 array[array_index]='\0';
 remove_trailing_spaces(array);
 
  if(array[0] == '"' && array[array_index-2] == '"'){ /*if start and end of definition has double quotes, remove them and sent the string to be converted to binary*/

    array[array_index-2]='\0';
    array++;

    return string_to_binary(array, data_length,line,unfolded_filename);    

    }
/*if there are no double quotes, the definition isnt valid and error will be printed*/
printf("error: missing \" in .string definition. line: %d, file: %s\n",line,unfolded_filename); 
global_error_flag=true;

  }



 return NULL;  
 
}


