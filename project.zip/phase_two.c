#include <stdio.h>
#include "phase_two.h"
#include "instructions.h"
#include "constant_sizes.h"
#include"conversions.h"
#include "data_structures.h"
#include "error_handler.h"
#include <string.h>
#include "label_handler.h"
#include <stdlib.h>
#include "memory_releaser.h"

/*impelemnts phase two of the assembler: completes the binary code by adding the label represination in binary. also creates extrn entry and object files*/
void phase_two(char *unfolded_filename){

 char *ob_filename=NULL,*ent_filename=NULL,*ext_filename=NULL; /*file names to be created*/
 FILE *ob=NULL,*ent=NULL,*ext=NULL; /* the pointers to the files*/
 str_int_node *label_table_head=NULL,*extrn_head=NULL;
 str_node *binary_instructions_head=NULL;
 label_table_head=label_table;                   /*set up head for label table and binary instructions*/
 binary_instructions_head=binary_instructions;
 extrn_head=extrn_table;

 ob_filename = (char*)malloc((strlen(unfolded_filename)+1) * sizeof(char));
 ent_filename = (char*)malloc((strlen(unfolded_filename)+2) * sizeof(char));   /*allocate memory for each file name*/
 ext_filename = (char*)malloc((strlen(unfolded_filename)+2) * sizeof(char));
 unfolded_filename[strlen(unfolded_filename)-3]='\0'; /*remove .am from file name*/
 strcpy(ob_filename,unfolded_filename);
 strcat(ob_filename,".ob");
 strcpy(ent_filename,unfolded_filename);  /*set up new file extensions for the given file name accordingly*/
 strcat(ent_filename,".ent");
 strcpy(ext_filename,unfolded_filename);
 strcat(ext_filename,".ext");
 
 if(label_table !=NULL && label_table->name !=NULL){

   change_label_to_binary(&binary_instructions,&extrn_table,binary_instructions_head,label_table,label_table_head,unfolded_filename);
   }

 memory_error_handler(IC,DC,unfolded_filename);

 if(entry_table!=NULL && !global_error_flag){ /* if no errors detected and there are entey definitions, create .ent file*/

   ent = fopen(ent_filename, "w");
    
   while(entry_table!=NULL && entry_table->name!=NULL){

     fprintf(ent,"%s\t%d\n",entry_table->name,entry_table->index); /*write to the file all entery label names and indexes*/
     entry_table = entry_table->next;
     }
   }

 if(extrn_table!=NULL && !global_error_flag){ /* if no errors detected and there are extern definitions, create .ext file*/

   ext = fopen(ext_filename, "w");

   while(extrn_table!=NULL && extrn_table->name!=NULL){

     fprintf(ext,"%s\t%d\n",extrn_table->name,extrn_table->index); /*write to the file all extern label names and indexes*/
     extrn_table = extrn_table->next;
     }
   }

 if(!global_error_flag){ /*if there are no errors, create .ob file*/

   ob = fopen(ob_filename, "w");
   fprintf(ob,"%d %d\n",IC,DC);

   while(binary_instructions!=NULL){
   
     fprintf(ob,"%s\n",binary_string_to_base_sixty_four(binary_instructions->data));  /*write to the file all instruction lines in base 64*/
     binary_instructions = binary_instructions->next;
     }
   }
/*-----------------------------------------------------------------------------freeing memory and closing files--------------------------------------------------------------------------------*/

 if(!global_error_flag){

   fclose(ob);
   fclose(ent);
   fclose(ext);
   }

 free(ob_filename);
 free(ent_filename);
 free(ext_filename);
 free_str_int_list(&label_table_head); /*also frees entry table*/
 free_str_int_list(&extrn_head);
 free_str_list(&binary_instructions_head);
 label_table=NULL;
 extrn_table=NULL;
 entry_table=NULL;
 binary_instructions=NULL;
 global_error_flag=false;
 IC=0;
 DC=0;

}
