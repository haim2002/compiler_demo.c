#ifndef MACRO_EXPANDER_H
#define MACRO_EXPANDER_H
#include <stdbool.h>

void macro_expander(char* );


#endif 

