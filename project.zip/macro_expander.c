#include <stdio.h>
#include "macro_expander.h"
#include "macro_processor.h"
#include "data_structures.h"
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "constant_sizes.h"
#include "error_handler.h"
#include "memory_releaser.h"

/*the function extends the macro to its defenition and delets definitions and the names of the macros from the original code*/
void macro_expander(char *filename){


 char buffer[MAX_ROW_LENGTH];
 size_t length=strlen(filename);
 char *unfolded_filename=(char*)malloc((length+1)* sizeof(char));
 bool flag= false;
 FILE *file,*unfolded_file;
 str_node *snode =NULL,*head=NULL;
 snode=new_str_node(NULL,NULL);
 head=snode;
 /*creating new file and renaming it a given filename.am instead of.as*/
 strcpy(unfolded_filename, filename);
 strcat(unfolded_filename,".am");
 
 strcat(filename,".as"); 
 file = fopen(filename, "r");

if (file == NULL) { /*coudlnt open file*/
 
  printf("Error opening file: %s\n", filename);
  global_error_flag = true;
  return;
}

 unfolded_file=fopen(unfolded_filename, "w");
 detect_macro_names(&snode, head,file);
 assign_macro_data_to_name(&snode, head,file);

  while (fgets(buffer, MAX_ROW_LENGTH, file) != NULL){ /*check if end of file*/ 
 

    while(snode!=NULL && !flag){



      if(is_macro(buffer)){  /*if macro defention detected, go to next line in file untill macro ended*/

          while(!end_of_macro(buffer)){

            fgets(buffer, MAX_ROW_LENGTH, file);

          }
        fgets(buffer, MAX_ROW_LENGTH, file);
      }

/*if a macro detected, extand the macro to its code line*/
  if(is_name_of_macro(snode,buffer) && !is_macro(buffer)){

     fprintf(unfolded_file,"%s",snode->data);
     flag=true; /*signal for knowing its a macro*/    
     }    

  if(!flag){ /*searching for the macro name*/

    snode=snode->next;
     }
 }

  if(!flag){ /*skiping the name of the macro to not include in new unfolded file*/
 
    fprintf(unfolded_file,"%s",buffer); /*eventually, sends anything thats non macro realted to the new file*/
    }
 
/*reseting flag and returning to the head of the node*/
 flag=false;
 snode=head;

}



/*-----------------------------------------------------------------------------freeing memory and closing files--------------------------------------------------------------------------------*/

 free_str_list(&head);
 free(unfolded_filename);
 fclose(file);
 fclose(unfolded_file);	
}





















