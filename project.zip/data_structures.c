#include <stdio.h>
#include <stdlib.h>
#include "data_structures.h"

/*----------------------------------------------------------------------------------------------------------------*/
/*implementation of the string node data structure*/
str_node* new_str_node(char *name, char *data) {
   
 str_node *new_node = (str_node*)malloc(sizeof(str_node));
  
  if (new_node != NULL){
        
    new_node->name = name;
    new_node->data = data;
    new_node->next = NULL;
  }
 return new_node;
}

/*----------------------------------------------------------------------------------------------------------------*/
/*implementation of the string node data structure*/
str_int_node* new_str_int_node(char *name,char *type, int index) {
   
 str_int_node *new_node = (str_int_node*)malloc(sizeof(str_int_node));
  
  if (new_node != NULL){
        
    new_node->name = name;
    new_node->type = type;
    new_node->index = index;
    new_node->is_data = false;
    new_node->ic=0;
    new_node->dc=0;
    new_node->next = NULL;
    
  }
 return new_node;
}



/*----------------------------------------------------------------------------------------------------------------*/
/*setting the next string node data structure*/
void set_next(str_node **current_node, str_node *next_node){
   
  if ((*current_node) != NULL){
        
    (*current_node)->next = next_node;
    
  }
}

void set_next_str_int(str_int_node **current_node, str_int_node *next_node){
   
  if ((*current_node) != NULL){
        
    (*current_node)->next = next_node;
    
  }
}


str_node *binary_instructions=NULL; /*defined as extern in data_structures.h file. will contain all assmbler code translated to binary*/
str_int_node *label_table=NULL; /*defined as extern in data_structures.h file. will contain all labels, their index, and type*/
str_int_node *extrn_table=NULL; /*defined as extern in data_structures.h file. will contain all extern labels and their index*/
str_int_node *entry_table=NULL; /*defined as extern in data_structures.h file. will contain all entry labels adn their index*/







