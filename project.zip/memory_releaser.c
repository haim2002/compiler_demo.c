#include <stdio.h>
#include "memory_releaser.h"
#include <stdlib.h>
#include "data_structures.h"



void free_string_array(char ***string_array, int array_length){

 int i = 0;

 if((*string_array) == NULL) {
        return;
        }

 for(i=0; i < array_length; i++){

   free((*string_array)[i]);  
   }
  
 free((*string_array));
 (*string_array)=NULL;
 }



void free_str_int_list(struct str_int_node **head){


    str_int_node *temp = NULL;

 if ((*head) == NULL) {
        return;
    }


    

    while ((*head) != NULL) {

        temp=(*head);
        (*head)= (*head)->next;
        free(temp->name);
        free(temp->type);
        free(temp);
        }   
     
}


void free_str_list(struct str_node **head){

 str_node *temp = NULL;

 if ((*head) == NULL) {
        return;
    }

    while ((*head) != NULL) {

        temp=(*head);
        (*head)= (*head)->next;
        free(temp->data);
        free(temp->name);
        free(temp);
        }   

     
}
