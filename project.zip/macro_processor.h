#ifndef MACRO_PROCESSOR_H   
#define MACRO_PROCESSOR_H
#include <stdbool.h>
#define MACRO "mcro"
#define END_OF_MACRO "endmcro"

struct str_node;

bool is_macro(char[]);
bool end_of_macro( char[]);
char *extract_macro_name(char[], char*);
bool is_name_of_macro(struct str_node*,char[]);
void detect_macro_names(struct str_node**, struct str_node*,FILE *);
void assign_macro_data_to_name(struct str_node**, struct str_node*,FILE*);

#endif 
