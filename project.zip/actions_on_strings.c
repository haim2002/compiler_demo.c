#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "actions_on_strings.h"


/*check if a string is empty*/
bool string_is_empty(char string[]) {
   
 return(strcmp(string,"\n")==0 || strcmp(string,"\0")==0);
}
     
 



/*check if a string has nothing but spaces*/
bool string_is_spaces(char buffer[]){

  
int i=0;

 

while(buffer[i]!='\0'){

 if(!(isspace(buffer[i]))){
    
    return false;
    }
  i++;
  }

return true;
}

/*remove all traling spaces from a string*/
void remove_trailing_spaces(char *str){
    
 int length=0,last_non_space=0;
 length = strlen(str);

 if(str==NULL) {
       
   return;
    }

 
 if (string_is_empty(str)){
        
   return; 
   }

 last_non_space=length-1;

 while (last_non_space >= 0 && isspace(str[last_non_space])){ /*search for first non space char and save its index*/
 
   last_non_space--;
   }

 str[last_non_space + 1] = '\0'; /*remove all spaces by puting NULL terminator on the first index of space*/
}


/*check if a string has spaces*/
bool string_has_space(char str[]){

 int i=0;

 while(str[i]!='\n' && str[i]!='\0'){

   if(isspace(str[i])){

     return true;
     
     }
   i++;
   }

 return false;
}

/*check if a string is the definition of command in project (has ; at begining of line)*/
bool string_is_comment(char buffer[]){

 int index=0;

 while(isspace(buffer[index]) && buffer[index] != '\0'){ /*search for first non space char (if there is any)*/

   index++;
   }

 return buffer[index] == ';'; /*if first char is ; that its comment*/
 }










