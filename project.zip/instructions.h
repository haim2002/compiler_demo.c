#ifndef INSTRUCTIONS_H
#define INSTRUCTION_H
#include <stdbool.h>

#define CALL_TYPE_NUMBER 1
#define CALL_TYPE_LABEL 3
#define CALL_TYPE_REGISTER 5
#define NO_CALL_TYPE 0
#define ABSOLUTE 0
#define EXTERNAL 1
#define RELOCATABLE 2

extern int IC; /* extern counter for instructions*/
extern int DC; /* extern counter for data*/

extern const char *commands_array[];

extern const char mov[];
extern const char cmp[];
extern const char add[];
extern const char sub[];
extern const char lea[];
extern const char clr[];
extern const char inc[];
extern const char dec[];
extern const char jmp[];
extern const char bne[];
extern const char red[];
extern const char prn[];
extern const char jsr[];
extern const char nott[];
extern const char rts[];
extern const char stop[];
/*-----------------------------------------*/

extern const char *registers[];
extern const char *register_names[];

extern const char r0[];
extern const char r1[];
extern const char r2[];
extern const char r3[];
extern const char r4[];
extern const char r5[];
extern const char r6[];
extern const char r7[];
/*-----------------------------------------*/




/*-----------------------------------------*/
int command_to_number(const char[]);
bool is_command(char[]);
bool has_command(char[]);
bool is_register(char[]);
bool is_register_name(char[]);
int register_to_num(char []);
bool has_data_definition(char[]);
bool is_data_definition(char[]);
bool has_string_definition(char[]);
bool is_string_definition(char[]);
bool is_extrn_definition(char[]);
bool has_extrn_definition(char[]);
bool is_entry_definition(char[]);
bool has_entry_definition(char[]);
int op_type_decision(char[],int*,int*,int*,int*,int*,char*,char*);
int command_to_binary(char[], const char[],int,int*,int*,int*,int*,char*,char*);
int function_call_type_source(char[],int,int*,char*);
int function_call_type_destination(char[],int,int*,char*);
char **data_line_extraction(char[],int*,int,char*);

#endif
