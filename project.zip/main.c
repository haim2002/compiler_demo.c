#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "macro_expander.h"
#include "phase_one.h"
#include "phase_two.h"
#include "error_handler.h"

/* read file names from command line. activate 3 stages of assembler on the files*/
int main(int argc, char *argv[]) {
   

/*reading the name of the file*/

char *filename=NULL; 
int i=1;

 if (argc < 2) { /*did not detect a file name*/
        
   printf("please insert a file name\n");
   return 0;
   }


 for(i = 1; i <argc; i++){

   filename = (char*)malloc((strlen(argv[i]) + 1) * sizeof(char));
   strcpy(filename,argv[i]); /*copy names from command line*/
   macro_expander(filename); 

   if(!global_error_flag){

     phase_one(filename); 
     phase_two(filename);
     }
  }

 free(filename);
 
 return 0;
}
