#ifndef MEMORY_RELEASER_H
#define MEMORY_RELEASER_H


struct str_int_node;
struct str_node;

void free_string_array(char***,int);
void free_str_int_list(struct str_int_node**);
void free_str_list(struct str_node **);

#endif
