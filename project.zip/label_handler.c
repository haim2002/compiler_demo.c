#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "label_handler.h"
#include "instructions.h"
#include "error_handler.h"
#include "data_structures.h"
#include "constant_sizes.h"
#include "actions_on_strings.h"
#include"conversions.h"

/*------------------------------------------------------------------------------------------------------*/

/*checks if a string is capable of being lable*/
bool is_label(char buffer[]){

 int i=0;

 while(isspace(buffer[i]) && buffer[i] !='\0'){

   i++;
   }

 if(isalpha(buffer[i])){

   while(!isspace(buffer[i]) && buffer[i] !='\0' && i <= MAX_LABEL_LENGTH){ /*if there are not spaces and length <= 31 and it has : at the end*/

     if(buffer[i] ==':'){

       return true;
       }
     i++;
     }
   } 

 return false;
}
/*------------------------------------------------------------------------------------------------------*/

/*extract label name from a string*/
char *extract_label_name(char buffer[]){

 int buffer_index=0,label_index=0;
 char *label_name = (char*)malloc(MAX_LABEL_LENGTH * sizeof(char));

 while(isspace(buffer[buffer_index]) && buffer[buffer_index] !='\0'){ /*skip start spaces*/

   buffer_index++;
   }

 while(buffer[buffer_index]!= ':'){ /*copy the label chars without :*/

  label_name[label_index] = buffer[buffer_index];
  buffer_index++;
  label_index++;
  } 

 label_name[label_index] = '\0';

 return label_name;
}

    

/*------------------------------------------------------------------------------------------------------*/

/*stores labels and their index in a linked list*/
void store_label_and_index(char buffer[],str_int_node **label_table, str_int_node *head ,int index){

 char *label_name = (char*)malloc(MAX_LABEL_LENGTH * sizeof(char));
 str_int_node *temp=NULL;

 if(is_label(buffer)){

   strcpy(label_name,extract_label_name(buffer));  /*copy the label's name to a string*/
    
   if((*label_table)->name == NULL){ /*if its the first label*/
    
     (*label_table)->name=(char*)malloc((strlen(label_name)+1) * sizeof(char)); /*allocate memory and copy to the node the lable's name*/
     strcpy((*label_table)->name,label_name);
     (*label_table)->index=index;

     if(has_data_definition(buffer) || has_string_definition(buffer)){ /*if its string or data label*/

        (*label_table)->is_data=true; /*mark as data label*/
        (*label_table)->ic=IC; /*save current ic and dc for later changes in index*/
        (*label_table)->dc=DC;
        }        
     }

   else{

     while((*label_table)->next!=NULL){ /*if not first label, move to next node until its the last one*/

      (*label_table)=(*label_table)->next;
      }
      
     temp= new_str_int_node(NULL,NULL,0);
     temp->name=(char*)malloc((strlen(label_name)+1) * sizeof(char)); /*create new node to be added as last in the list*/
     strcpy(temp->name,label_name);
     temp->index=index;
  


     if(has_data_definition(buffer) || has_string_definition(buffer)){ /*check if added node is data or string label and update it accordingly*/

        temp->is_data=true;
        temp->ic=IC;
        temp->dc=DC;
        }  
 
     set_next_str_int(label_table,temp); /*add new node at the end of the list*/
     temp=NULL;
  }
}
   
(*label_table)=head;
free(label_name);
}


/*------------------------------------------------------------------------------------------------------*/

/*extract extern label names into an array of strings*/
void extrn_extraction(char ***array,char buffer[],int *extrn_length,int line){

 int temp_index=0;

 if(has_extrn_definition(buffer)){
 
   temp_index=(strstr(buffer,".extern")-buffer+strlen(".extern")); /*the index of the first letter after .extern definition*/

   while(isspace(buffer[temp_index]) && buffer[temp_index] != '\0'){ /*skip spaces untill first letter letter*/

     temp_index++;
     }

   (*extrn_length)++; 
   (*array) = (char**)realloc((*array),(*extrn_length) *sizeof(char*)); /*increase array length*/
   (*array)[(*extrn_length)-1] = (char*)malloc((strlen(buffer+ temp_index) + 1) *sizeof(char)); /*allocate memory foe new name*/
   strcpy((*array)[(*extrn_length)-1],buffer+temp_index); /*copy de name and remove trailing spaces from it*/
   remove_trailing_spaces((*array)[(*extrn_length)-1]);
   }
 
}

/*------------------------------------------------------------------------------------------------------*/

/*extract entry label names into an array of strings*/
void entry_extraction(char ***array ,char buffer[],int *entry_length,int line){

 int temp_index=0;
 

 if(has_entry_definition(buffer)){
 
   temp_index=strstr(buffer,".entry")-buffer+strlen(".entry"); /*the index of the first letter after .entry definition*/

   while(isspace(buffer[temp_index]) && buffer[temp_index] != '\0') { /*skip spaces untill first letter letter*/

     temp_index++;
     }
  
   (*entry_length)++;
   (*array) = (char**)realloc((*array),(*entry_length) *sizeof(char*));/*increase array length*/
   (*array)[(*entry_length)-1] = (char*)malloc((strlen(buffer+ temp_index) + 1) *sizeof(char));/*allocate memory foe new name*/
   strcpy((*array)[(*entry_length)-1],buffer+temp_index); /*copy de name and remove trailing spaces from it*/
   remove_trailing_spaces((*array)[(*entry_length)-1]);
   } 
}

/*------------------------------------------------------------------------------------------------------*/

/*decides if a label is entry, add extern labels to the list, create new extern and entry tables and deals with collision in definitions*/
void label_type_decision(str_int_node **label_table,str_int_node ** extrn_table,str_int_node ** entry_table, str_int_node *head, char **entry,
                        char **extrn,int entry_length,int extrn_length,char *unfolded_filename){

 int entry_index=0,extrn_index=0;
 int type_size=6; /*the size of the words extrn and entry + null terminator*/
 str_int_node *temp=NULL,*current_entry=NULL;

(*label_table)=head;



 if((*label_table) == NULL){ /*no labels in file*/

   return;
   }

 while(entry_index < entry_length){ /*uses the array of entry names to update existing nodes into entery ones.the while makes sure that overflow wont happen */
  
   if((*label_table)!=NULL){

     if((*label_table)->name!=NULL && strcmp((*label_table)->name, entry[entry_index]) ==0){ /*if the label name from the node matches the label name from the array*/

       (*label_table)->type= (char *)malloc(type_size * sizeof(char));
       strcpy((*label_table)->type,"entry"); /*update the label in label_table to entry*/
       current_entry=new_str_int_node(NULL,NULL, 0);  /*create new list that will have only entry labels*/   
       current_entry->name = (*label_table)->name; /*copy information from label_table*/
       current_entry->index = (*label_table)->index;

         if((*label_table)->is_data){ /*if the label also data type*/

           current_entry->is_data = (*label_table)->is_data;
           current_entry->dc = (*label_table)->dc; /*copy ic and dc information from label_table*/
           current_entry->ic = (*label_table)->ic;
           }

       current_entry->next = (*entry_table); /*add entry label to entry list*/
       (*entry_table) = current_entry;
       (*label_table)= head;
       entry_index++;
       }

     else{ /*if this is not entry label, continue searching*/

       (*label_table) =(*label_table)->next;
       }
     }

   if((*label_table)==NULL){ /*if there is entry definition but no label definition in current file*/

     printf("error: entery label \"%s\" not defined in the file . file %s\n",entry[entry_index],unfolded_filename);
     global_error_flag=true;
     (*label_table)= head;
     entry_index++;  /*continue the search*/
     }
   }

 (*label_table)=head;

 while(extrn_index < extrn_length && (*label_table)!=NULL){ /*uses the array of extrn names to update existing nodes into extrn ones.the while makes sure that overflow wont happen */

   if((*label_table)->type ==NULL && strcmp((*label_table)->name, extrn[extrn_index]) == 0 ){ /*if label declared as extern and also defiend as normal label in the same file*/

     printf("error: cant define label \"%s\" as extern. label already defined in the file. file %s\n",extrn[extrn_index],unfolded_filename);
     global_error_flag=true;
     extrn_index++;
     (*label_table)= head;
     }

  /*if label was defined as entery and extern*/
   if((*label_table)->name != NULL  && extrn_index < extrn_length && strcmp((*label_table)->name,extrn[extrn_index]) ==0 && strcmp((*label_table)->type,"entry") == 0 ){
    
     printf("error: cant define label \"%s\" as entry. label already defined as extern. file %s\n",extrn[extrn_index],unfolded_filename);
     global_error_flag=true;
     extrn_index++;
     (*label_table)= head;
     }

   if((*label_table)->next == NULL ){
     

     /*add all extern labels into label table*/
     temp = new_str_int_node(NULL,NULL, 0);
     temp->type= (char *)malloc(type_size * sizeof(char));
     temp->name= (char *)malloc((strlen(extrn[extrn_index])+1) * sizeof(char));
     strcpy(temp->type,"extrn");
     strcpy(temp->name,extrn[extrn_index]);
     set_next_str_int(label_table,temp);
     temp=NULL;
     extrn_index++;
     (*label_table)= head;
     }

   (*label_table)=(*label_table)->next;
   }

 (*label_table)=head;
  current_entry=NULL;
}
/*------------------------------------------------------------------------------------------------------*/

/* sets a_r_e according the the type of the label and sends them to be converted to binary. handles the scenario of no undefined label that been used as source or destination for a command*/
void change_label_to_binary(str_node **binary_instructions,str_int_node **extrn_table,str_node *binary_instructions_head,str_int_node *label_table,
                            str_int_node *label_table_head,char *unfolded_filename){
 
 int index=LABEL_INDEX;
 int a_r_e;
 str_int_node *current_extrn=NULL;

 while(label_table !=NULL ){

   while((*binary_instructions) != NULL){

     if(strcmp((*binary_instructions)->data, label_table->name) == 0){ /*search for a label in the code to translate to binary
                                                                     (earlier all label type addresses were set to be their name for easier convertion)*/
       if(label_table->type == NULL || strcmp(label_table->type,"entry") == 0){ /*if label is not extern type*/

         a_r_e = RELOCATABLE_A_R_E; /*set a_r_e to be 10b*/
         convert_label_to_binary(binary_instructions,label_table->index,a_r_e); /*convert to binary with the label index and a_r_e = 10*/
         (*binary_instructions)=binary_instructions_head; /* reset node and index*/
         index=LABEL_INDEX;
         }

       if(label_table->type !=NULL && strcmp(label_table->type,"extrn") == 0){ /*if label is extern type*/

         a_r_e = EXTRN_A_R_E; /*set a_r_e to 01b*/
         convert_label_to_binary(binary_instructions,0,a_r_e);/*convert extern to binary with 2 to 12 bits as 0 and 0 and 1 bits to 01*/
         current_extrn=new_str_int_node(NULL,NULL, 0);
         current_extrn->name = label_table->name;       /*creat new list that will contain all extern labels*/
         current_extrn->index = index;
         current_extrn->next = (*extrn_table);
         (*extrn_table) = current_extrn; 
         (*binary_instructions)=binary_instructions_head; /* reset node and index*/
         index=LABEL_INDEX;
         }
       }
     
     (*binary_instructions) = (*binary_instructions)->next; /*moving to next binary instruction until a label found*/
     index++;
     }
 
   label_table = label_table->next; /*when label foud, move to next label and reset the instruction table*/
   (*binary_instructions)=binary_instructions_head;
   index=LABEL_INDEX;
   }

 (*binary_instructions)=binary_instructions_head;
 label_table=label_table_head;



 while((*binary_instructions)!=NULL){

   if(string_to_ptr_int((*binary_instructions)->data) == NULL){  /*if there is still label name left, it means that there was no definition or decleration as extern of that specific label in the file*/

     printf("error: uknown label %s. file:%s\n",(*binary_instructions)->data,unfolded_filename);
     global_error_flag=true;   
     } 
  
   (*binary_instructions) = (*binary_instructions)->next; 
   }

 (*binary_instructions)=binary_instructions_head;
}


/*------------------------------------------------------------------------------------------------------*/

/*the function adjusts new indexes to data type label according to ic and dc*/
void adjust_data_label_index(str_int_node **label_table,str_int_node *label_table_head){

 int new_label_index=0;

 while((*label_table) != NULL){

   new_label_index=0;

   if((*label_table)->is_data){ /*if its a data label*/
       
       /*the very first place for data label to be is at ic. if its not the first data label, dc will compensate and move index to after the previous data labels*/
       new_label_index= (*label_table)->dc+IC+LABEL_INDEX; 
       (*label_table)->index=new_label_index; /*assaing the new index to the data label*/
       }

   (*label_table)=(*label_table)->next;
   }

 (*label_table)= label_table_head;
}



