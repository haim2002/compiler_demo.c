#include <stdio.h>
#include"conversions.h"
#include <stdlib.h>
#include "actions_on_strings.h"
#include "instructions.h"
#include "error_handler.h"
#include <string.h>
#include "constant_sizes.h"
#include <ctype.h>
#include "data_structures.h"

/*all base 64 chars in order*/
const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";


/*the function converts decimal value to its binary representation*/
 char* decimal_to_binary(unsigned int value) {
 unsigned int bit =0;
 char* binary_representation = (char*)malloc((INSTRUCTION_SIZE+1) * sizeof(char)); /*Allocate space for the binary string in 12 bits + NULL terminator*/

 int i=11;

 for (i = 11; i >= 0; i--) {
    
   bit = (value >> i) & 1; /*extract bits from a given number*/
   binary_representation[11 - i] = bit + '0'; /*Convert the bit to '1' or '0'*/
   }
  
   binary_representation[12] = '\0'; /*Null terminator to mark the end of the string*/
   return binary_representation;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------*/

/*cheks if the string is a number. if so, and converts it to a pointer to int.*/
int *string_to_ptr_int(char num[]) {
   
 int *result=NULL; 
 char *ptr = NULL;
 long converted_value = strtol(num, &ptr, 10); /*using strtol to convert all number in a given string to decimal integer*/

 if(num == NULL || string_is_empty(num) || string_is_spaces(num) || string_has_space(num) || *ptr!= '\0'){ /*if string empty or has only spaces or has non number char*/

  return NULL;
}

 result = (int *)malloc(sizeof(int));
 *result = (int)converted_value;

 return result;

}

/*---------------------------------------------------------------------------------------------------------------------------------------------*/

/*converts instruction's adresses type and command to ine binary code*/
int instruction_command_line_to_binary(int source, int instruction, int destination) {
    
 int binary_instruction = 0;
 int a_r_e = 0; /*command line a.r.e allways 0*/

 binary_instruction |= (source << 9);        /*Place source at bits 9 to 11*/
 binary_instruction |= (instruction << 5);   /*Place instruction at bits 5 to 8*/
 binary_instruction |= (destination << 2);   /*Place destination at bits 2 to 4*/
 binary_instruction |= a_r_e;               /*Place a.r.e at bits 0 and 1*/
 return binary_instruction;
}


/*---------------------------------------------------------------------------------------------------------------------------------------------*/


/*calcuates the amount of lines needed to be created in binary according to destination and source adresses and converts them to binary if its not a label, according to the laws of the given assembly*/
char **addresses_to_array(int source, int destination,int source_value, int destination_value,char *source_label_name,char *destination_label_name, int *IC,int *address_size) {
    
 int first_address = 0,second_address=0, a_r_e = 0,length=1,source_maker=0,destination_maker=0;
 char ** command_addresses_array = NULL;


 if(source == ERROR || destination == ERROR){

   return NULL;
   }


/*determins the type of the source and destination addresses*/

 if(source == CALL_TYPE_REGISTER){

   source_maker |= (source_value << 7);        /*Place source at bits 7 to 11*/
   source_maker |= a_r_e;                      /*Place a.r.e at bits 0 and 1*/
   }

 if(destination == CALL_TYPE_REGISTER){
  
   destination_maker|= (destination_value << 2);   /*Place destination at bits 2 to 6*/
   destination_maker |= a_r_e;                     /*Place a.r.e at bits 0 and 1*/
   }

 if(source == CALL_TYPE_NUMBER){
   
   source_maker |= (source_value<< 2);        /*Place source at bits 2 to 11*/                                          
   source_maker |= a_r_e;                          /*Place a.r.e at bits 0 and 1*/
   }

 if(destination == CALL_TYPE_NUMBER){
   
   destination_maker |= (destination_value<< 2);        /*Place destination at bits 2 to 11*/                                          
   destination_maker |= a_r_e;                          /*Place a.r.e at bits 0 and 1*/
   }


 /*if all addresses registrers or there is only one address and it's register but cant be no adresses at all*/
 if((source == CALL_TYPE_REGISTER || source == NO_CALL_TYPE)  && (destination == CALL_TYPE_REGISTER || destination == NO_CALL_TYPE) 
   && (source != NO_CALL_TYPE || destination != NO_CALL_TYPE)){ 

   first_address = source_maker+destination_maker; /*sum of both makers will make the whole binary code of that address*/

   command_addresses_array = (char**)realloc( command_addresses_array,length * sizeof(char*)); /* allocating memory for the array of strings in size of length and the string itself to size of 12 bit*/
   command_addresses_array[length-1] = (char*)malloc(12 * sizeof(char));

   sprintf(command_addresses_array[length-1],"%d",first_address); /*converting the address to string and saving it in the array for later to be converted to binary*/
   *address_size=length;
   *IC+=length; /*increasing IC by the number of commands to be converted to binary*/

   return command_addresses_array; 
   }  


/*if both addresses are numbers or one of address is number and the other register but not when both addresses registers*/
 if((source == CALL_TYPE_REGISTER || source == CALL_TYPE_NUMBER)  && (destination == CALL_TYPE_REGISTER || destination == CALL_TYPE_NUMBER) 
   && (source != CALL_TYPE_REGISTER || destination != CALL_TYPE_REGISTER)){

   length++; /*increasing length becuase 2 seperated translations needed*/
   first_address = source_maker; /*assigning to addresses by order of appearance*/
   second_address=destination_maker;

   command_addresses_array = (char**)realloc( command_addresses_array,length * sizeof(char*)); /* allocating memory for the array of strings in size of length and the two strings to size of 12 bit*/
   command_addresses_array[length-2] = (char*)malloc(12 * sizeof(char));
   command_addresses_array[length-1] = (char*)malloc(12 * sizeof(char));

   sprintf(command_addresses_array[length-2],"%d",first_address); /*converting both addresses to string and saving them in the array for later to be converted to binary*/
   sprintf(command_addresses_array[length-1],"%d",second_address);
   *address_size=length;
   *IC+=length; /*increasing IC by the number of commands to be converted to binary*/

   return command_addresses_array; 
   }  


/*if destination is number and there is no source*/
 if (destination == CALL_TYPE_NUMBER && source == NO_CALL_TYPE){

   first_address=destination_maker;  /*assigning the only address*/

   command_addresses_array = (char**)realloc( command_addresses_array,length * sizeof(char*)); /* allocating memory for the array of strings in size of length and the string to size of 12 bit*/
   command_addresses_array[length-1] = (char*)malloc(12 * sizeof(char));

   sprintf(command_addresses_array[length-1],"%d",first_address); /*converting the address to string and saving it in the array for later to be converted to binary*/
   *address_size=length;
   *IC+=length; /*increasing IC by the number of commands to be converted to binary*/

   return command_addresses_array; 
   }  



/*if source is label and destination number or register*/
 if(source == CALL_TYPE_LABEL && (destination == CALL_TYPE_NUMBER || destination == CALL_TYPE_REGISTER) ){

   length++;
   second_address=destination_maker; 
  
   command_addresses_array = (char**)realloc(command_addresses_array,length * sizeof(char*));
   command_addresses_array[length-2] = (char*)malloc((strlen(source_label_name)+1) * sizeof(char));
   command_addresses_array[length-1] = (char*)malloc(12 * sizeof(char));

   strcpy(command_addresses_array[length-2],source_label_name);
   sprintf(command_addresses_array[length-1],"%d",second_address); /*converting the address to string and saving it in the array for later to be converted to binary*/
   *address_size=length;
   *IC+=length; /*increasing IC by the number of commands to be converted to binary*/

   return command_addresses_array; 
   }



/* if source is register or number and destination is label*/
 if((source == CALL_TYPE_REGISTER || source == CALL_TYPE_NUMBER) && destination == CALL_TYPE_LABEL ){

   length++;
   first_address=source_maker; 
  
   command_addresses_array = (char**)realloc(command_addresses_array,length * sizeof(char*));
   command_addresses_array[length-2] = (char*)malloc(12 * sizeof(char));
   command_addresses_array[length-1] = (char*)malloc((strlen(destination_label_name)+1) * sizeof(char));
   sprintf(command_addresses_array[length-2],"%d",first_address);
   strcpy(command_addresses_array[length-1],destination_label_name);
   
   *address_size=length;
   *IC+=length;

   return command_addresses_array; 
   }


/* if source is register or number and destination is label*/
 if(source == CALL_TYPE_LABEL  && destination == CALL_TYPE_LABEL ){

   length++;
   command_addresses_array = (char**)realloc(command_addresses_array,length * sizeof(char*));
   command_addresses_array[length-2] = (char*)malloc(strlen(source_label_name)+1 * sizeof(char));
   command_addresses_array[length-1] = (char*)malloc((strlen(destination_label_name)+1) * sizeof(char));
   strcpy(command_addresses_array[length-2],source_label_name);
   strcpy(command_addresses_array[length-1],destination_label_name);
   
   *address_size=length;
   *IC+=length;

   return command_addresses_array; 
   }

/*if there is no source and destination is label*/
 if(source == NO_CALL_TYPE && destination == CALL_TYPE_LABEL){

  command_addresses_array = (char**)realloc(command_addresses_array,length * sizeof(char*));
  command_addresses_array[length-1] = (char*)malloc((strlen(destination_label_name)+1) * sizeof(char));

  strcpy(command_addresses_array[length-1],destination_label_name);
   *address_size=length;
  *IC+=length;
   
   return command_addresses_array; 
   }
  
   
return NULL;


}

/*-------------------------------------------------------------------------------------------------------------------------------------*/

/*converts .data instruciton into binary code*/
char **data_to_binary(char array[],int *data_length,int line,char *unfolded_filename){

 char **array_of_data=NULL;
 int array_index=0,data_index=0;
 data_error_handler(array,line, unfolded_filename);
 *data_length=0;

 /*if no error was detected*/
 if(!global_error_flag){

   while(array[array_index]!='\0'){

     /*only numbers ,- and + allowed to be in data decleration*/
     if(isdigit(array[array_index])|| array[array_index] =='-' || array[array_index] =='+'){
   
         (*data_length)++;
        array_of_data=(char**)realloc(array_of_data,((*data_length)) *sizeof(char*));
         array_of_data[(*data_length)-1] = (char*)malloc((INSTRUCTION_SIZE+1) *sizeof(char));   
  
     /*connect all digits in row into one number, put it in array of strings*/
     while(isdigit(array[array_index]) || array[array_index] =='-' || array[array_index] =='+' ){
   
        array_of_data[(*data_length)-1][data_index]=array[array_index];
        array_index++;
        data_index++;
        }

      /*mark end of number*/
      array_of_data[(*data_length)-1][data_index]='\0';
  
      /*check if the number is legal. if not , return NULL*/
      value_threshold_handler(line,(*string_to_ptr_int(array_of_data[(*data_length)-1])),unfolded_filename);

       if(global_error_flag){

          return NULL;
          }

      /*converts the number to binary*/
      array_of_data[(*data_length)-1] =  decimal_to_binary((*string_to_ptr_int(array_of_data[(*data_length)-1])));
      data_index=0;
 }

  array_index++;
  }
}
 return array_of_data; /*return all numbers in.data converted to binary in seperate slots in array of strings*/ 

}

/*-------------------------------------------------------------------------------------------------------------------------------------*/

/*converts .string instruction into binary code*/
char **string_to_binary(char array[],int *string_length,int line,char *unfolded_filename){

 char **array_of_string=NULL;
 int array_index=0,ascii_code=0,array_of_string_length=0;
;
 
 /*string_error_handler(array,line, unfolded_filename);*/
 *string_length=0;

  ascii_code= array[array_index];

/*checks if the char can be represented as ascii value*/
   while(array[array_index]!='\0'){

    ascii_code= array[array_index];                                                  
    
    if(ascii_code<0 || ascii_code>127){

      printf("error: unknown character in .string definition. line: %d, file: %s\n",line,unfolded_filename);
      global_error_flag=true;
      return NULL;   
      }
    

     while(array[array_index]!='\0' && ascii_code >=0 && ascii_code<=127  ){


        (*string_length)++;
        ascii_code = (array[array_index]); /*convert the char into ascii value*/
        array_of_string=(char**)realloc(array_of_string,((*string_length)) *sizeof(char*));/*extend the array's length and create new slot for new line of ascii code
                                                                                                   later to be converted to binary*/
        array_of_string[(*string_length)-1] = (char*)malloc((INSTRUCTION_SIZE+1) *sizeof(char)); 
        strcpy(array_of_string[(*string_length)-1],decimal_to_binary(ascii_code)); /*copy converted ascii code to the array*/
        array_index++;
        }
         array_of_string_length= strlen(array_of_string[(*string_length) - 1]);;
         array_of_string[(*string_length)-1][array_of_string_length]='\0';

      }
       


 (*string_length)++;
 array_of_string=(char**)realloc(array_of_string,((*string_length)) *sizeof(char*));  /*create the end of the string(ascii value 0 converted to binary*/
 array_of_string[(*string_length)-1] = (char*)malloc((INSTRUCTION_SIZE+1) *sizeof(char));    
 strcpy(array_of_string[(*string_length)-1],decimal_to_binary(0));



   return array_of_string;
}
  /*converts label type addresses into representative binary code according to their A,R,E and index*/
void convert_label_to_binary(str_node **binary_instructions, int index, int a_r_e){

  int binary_representation = 0;

 binary_representation |= (index << 2);        /*Place index at bits 2 to 11*/
 binary_representation |= a_r_e;               /*Place a.r.e at bits 0 and 1*/
 strcpy((*binary_instructions)->data,decimal_to_binary(binary_representation));
 }
    





/*the function converts every six bits of binary code into one base 64 char*/
char* binary_string_to_base_sixty_four(char* binary_str) {



 int index = 0,i=0,j=0;
 char result[3];
 char *returned_result = (char*)malloc(3); /*allocate memory for 2 chars and null terminator*/
    
 for(j = 0; j < 2; j++){ /*repeat twice for the entire 12 bits to be converted*/

   for (i = 0; i < INSTRUCTION_SIZE/2; i++) {

     index = (index << 1) | (*binary_str++ - '0'); /*converts 6 bits to decimal for later to be used as index for encoding with base64_chars array*/
     }
   
      
   result[j]=base64_chars[index]; /*place designated base 64 in the right place of result*/
   index=0;
   }
   
 result[2]='\0'; /*NULL terminator*/
 strcpy(returned_result,result); /*copy result to veriable that can be returned*/
 return returned_result;
}











