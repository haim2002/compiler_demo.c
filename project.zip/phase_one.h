#ifndef PHASE_ONE_H
#define PHASE_ONE_H



void phase_one(char *);

#endif
