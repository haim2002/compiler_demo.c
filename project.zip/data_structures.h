#ifndef DATA_STRUCTURES_H 
#define DATA_STRUCTURES_H
#include <stdbool.h>

typedef struct str_node {
    
  char *name;
  char *data;
  struct str_node* next;
    }str_node;



typedef struct str_int_node {
    
  char *name;
  char *type;
  int index;
  bool is_data;
  int ic;
  int dc;
  
  struct str_int_node* next;
    }str_int_node;



str_node* new_str_node(char *, char *);
void set_next(str_node **, str_node *);

str_int_node* new_str_int_node(char *,char *, int );
void set_next_str_int(str_int_node **, str_int_node *);




extern str_node *binary_instructions;
extern  str_int_node *label_table;
extern str_int_node *extrn_table;
extern str_int_node *entry_table;
#endif 

