#include <stdio.h>
#include "phase_one.h"
#include "instructions.h"
#include "constant_sizes.h"
#include"conversions.h"
#include "data_structures.h"
#include "error_handler.h"
#include "label_handler.h"
#include <stdlib.h>
#include <string.h>
#include "actions_on_strings.h"
#include "memory_releaser.h"

/*impelemnts phase one of the assembler: partly converts commands to binary. creats general label table, also specific one for extern and entern.*/
void phase_one(char *unfolded_filename){

 int source_value=0,destination_value=0; /*values of source and destination call type*/
 int source=0,destination=0; /*represents the calltype of source and destination*/
 int line_index=1,command_index=0 ,data_index=0,address_index=0; /*indication for dedicated porpuse*/ 
 int extrn_length=0,entry_length=0,address_length=0,data_length=0; /*all length will be sent to function to later be used as indicator to prevent out of bounds indexes*/
 int command_result=0; /*storing the result of the fist command line of every command*/
 char buffer[MAX_ROW_LENGTH];
 char *source_label_name=NULL,*destination_label_name=NULL;
 char **address=NULL,**data=NULL,**extrn=NULL,**entry=NULL;
 str_int_node *label_table_head=NULL;
 str_node *binary_instructions_head=NULL,*binary_instruction_current=NULL,*binary_instruction_current_command=NULL, 
                                       *data_current=NULL,*data_head=NULL,*data_node=NULL;

 FILE *unfolded_file;
 unfolded_filename[strlen(unfolded_filename)-3]='\0'; /*change file name to .am instead of .as*/
 strcat(unfolded_filename,".am");
 unfolded_file = fopen(unfolded_filename, "r");

 label_table= new_str_int_node(NULL,NULL,0);  
 label_table_head=label_table; /*set label head node*/

 source_label_name = (char*)malloc(MAX_LABEL_LENGTH * sizeof(char));     /*will be used as temporary name holders for source and destination if they are labels*/
 destination_label_name = (char*)malloc(MAX_LABEL_LENGTH * sizeof(char));

  while (fgets(buffer, MAX_ROW_LENGTH, unfolded_file) != NULL) {

    
   if(string_is_comment(buffer) || strcmp(buffer, "\n") == 0){
     
     line_index++; /*ignoring completly the comment line and empty line*/  
     }

   else{
         
     line_syntax_handler(buffer,line_index,unfolded_filename); /*basic syntax error check*/
     entry_extraction(&entry,buffer,&entry_length,line_index); /*if line has entry definition it will extract it to entry array*/
     extrn_extraction(&extrn,buffer,&extrn_length,line_index); /*if line has extern definition it will extract it to extern array*/

     /*the first line of command before converted to binary, therfor in decimal. also gathers information about source and destination*/
     command_result = op_type_decision(buffer, &command_index, &source_value, &destination_value, &source, &destination, source_label_name, destination_label_name); 
     command_error_handler(buffer, line_index, source, destination, command_index, unfolded_filename); /*check for errors in command line*/
     value_threshold_handler(line_index, source_value, unfolded_filename); /*check if source value is legal number(if its a number)*/
     value_threshold_handler(line_index, destination_value, unfolded_filename); /*check if destination value is legal number(if its a number)*/
     data = data_line_extraction(buffer,&data_length,line_index,unfolded_filename); /*if line has data definition it will extract it to data array*/
     label_error_handler(buffer, line_index, unfolded_filename, label_table); /*examines possible error of to be added label*/
     store_label_and_index(buffer, &label_table, label_table_head, IC+LABEL_INDEX); /*adds label to list of lables. index is determined by IC+100*/
        
     if (command_index >= 0 && command_index < OPERANDS_COUNT) { /*if op_type_decision detected legit command name*/
       
       binary_instruction_current_command =new_str_node(NULL,NULL);
       binary_instruction_current_command->data = (char *)malloc((INSTRUCTION_SIZE + 1) * sizeof(char)); /*create new node and copy their result(the first line of command) converted to binary*/
       strcpy(binary_instruction_current_command->data, decimal_to_binary(command_result));
             

         if (binary_instructions_head == NULL) { /*if its the first command of the file*/
 
           binary_instructions_head = binary_instruction_current_command;  /*set head to point on first command and set the instrcution table to look at head*/
           binary_instructions = binary_instruction_current_command;
           IC++; /*increase amount of commands*/
           }

         else{/*if not the first command in file*/

           binary_instructions->next = binary_instruction_current_command; /*set current command to be next in list*/
           binary_instructions = binary_instruction_current_command; /*forward list*/
           IC++;/*increase amount of commands*/
           }

         /* address will contain all other command lines derived from the first command line in a shape of aray of string(if there's any)*/
         address = addresses_to_array(source, destination, source_value, destination_value, source_label_name, destination_label_name, &IC, &address_length); 
                      
         if(address != NULL){ /*if address contains more code because of having source or destination addresses to convert*/

           address_index = 0; /*reset address index*/

           while(address_index < address_length){
                   
             binary_instruction_current = new_str_node(NULL, NULL);

               if(string_to_ptr_int(address[address_index]) != NULL){ /*check if address can be converted to all numbers therefore not a label*/
                      
                 binary_instruction_current->data = (char *)malloc((INSTRUCTION_SIZE + 1) * sizeof(char));
                 strcpy(binary_instruction_current->data, decimal_to_binary(*string_to_ptr_int(address[address_index])));  /*convert to binary and store in instruction list*/
                 } 
                       
               if(string_to_ptr_int(address[address_index]) == NULL){ /*if address is label therfore address[address_index] contains a name and not a number*/
                       
                 binary_instruction_current->data = (char *)malloc((strlen(address[address_index]) + 1) * sizeof(char));
                 strcpy(binary_instruction_current->data, address[address_index]); /*add the name to instruction list to be converted after more data on label becomes available*/    
                 }

                 binary_instructions->next = binary_instruction_current; 
                 binary_instructions = binary_instruction_current;
                 address_index++;
                 }

               free_string_array(&address,address_length); /*free memory after every use to avoid leaks*/
               }
               
             }
 
     if(data != NULL){ /*if its a data line*/
                
       data_index = 0; /*reset index*/
         
       while(data_index < data_length){
                           
         data_current = new_str_node(NULL, NULL);
         data_current->data = (char *)malloc((INSTRUCTION_SIZE + 1) * sizeof(char)); /*create new data list by order of appearance*/
         strcpy(data_current->data, data[data_index]);
         DC++; 
                  
         if(data_head == NULL){ /*if its first line of data in file*/

           data_head = data_current; /*set head to be first line of data*/
           data_node =  data_current; /*add data to data list*/
           }

         else{ /*already had data in file*/

           data_node->next =  data_current; /*add new node of data at the last node of the list*/
           data_node =  data_current;
           }

         data_index++;
         }
       free_string_array(&data,data_length); /*free memory after every use to avoid leaks*/
       }

     line_index++;
     }
   }

 /*adjusts new indexes to data type label according to ic and dc*/
 adjust_data_label_index(&label_table,label_table_head);
 extrn_table=new_str_int_node(NULL,NULL,0); /*allocate memory for extern and entry list that will store all of extern and entry labels*/
 entry_table=new_str_int_node(NULL,NULL,0);

/*detetmine if label is entry or extern. updates the entry and extrn tables*/
 if(label_table !=NULL && label_table->name !=NULL){


   label_type_decision(&label_table,&extrn_table,&entry_table,label_table_head,entry,extrn,entry_length,extrn_length,unfolded_filename); 
   }


 if(binary_instructions!=NULL){ /* if there were not only data instructions on file, add data list at the end of instrucions table*/

   set_next(&binary_instructions,data_head);
   binary_instructions = binary_instructions_head;
   }

 else{ /*if the file contains only data instruction, the instrucuin table is the data table*/

   binary_instructions = data_head;
   binary_instructions_head = binary_instructions;
   }



binary_instructions = binary_instructions_head;
label_table = label_table_head;

/*-----------------------------------------------------------------------------freeing memory and closing files--------------------------------------------------------------------------------*/

 binary_instructions_head=NULL;
 binary_instruction_current=NULL,
 binary_instruction_current_command=NULL;
 label_table_head=NULL;
 data_current=NULL;
 data_head=NULL;
 data_node=NULL;
 free(source_label_name);
 free(destination_label_name);
 free_string_array(&extrn,extrn_length);
 free_string_array(&entry,entry_length);
 fclose(unfolded_file);
}





