#ifndef CONVERSIONS_H
#define CONVERSIONS_H

struct str_node;

 char* decimal_to_binary(unsigned int);
 int* string_to_ptr_int(char[]);
 int instruction_command_line_to_binary( int,  int,  int);
 char **addresses_to_array(int,int,int,int,char*,char*,int*,int*);
 char **data_to_binary(char[],int *,int,char*);
 char **string_to_binary(char[],int *,int,char*);
 void convert_label_to_binary(struct str_node **, int, int);
 char* binary_string_to_base_sixty_four(char *);

extern const char base64_chars[];

#endif
