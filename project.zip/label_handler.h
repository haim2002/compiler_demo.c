#ifndef LABEL_HANDKER_H
#define LABEL_HANDKER_H

struct str_int_node;
struct str_node;

bool is_label(char[]);
char *extract_label_name(char[]);
void store_label_and_index(char[],struct str_int_node**,struct str_int_node*, int);
void extrn_extraction(char***,char[],int*,int);
void entry_extraction(char***,char[],int*,int);
void label_type_decision(struct str_int_node **,struct str_int_node **,struct str_int_node **,struct str_int_node *, char **,char **,int,int,char *);
void change_label_to_binary(struct str_node **,struct str_int_node **,struct str_node*,struct str_int_node *,struct str_int_node *,char *unfolded_filename);
void adjust_data_label_index(struct str_int_node **,struct str_int_node *);

#endif
