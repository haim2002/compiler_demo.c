#ifndef ERROR_HANDKER_H
#define ERROR_HANDKER_H

#include <stdbool.h>

struct str_int_node;

extern bool global_error_flag;
void label_error_handler(char[],int,char*,struct str_int_node*);
void command_error_handler(char[],int,int,int,int,char *);
void value_threshold_handler(int,int,char *);
void data_error_handler(char*,int,char *);
void line_syntax_handler(char[],int,char*);
void memory_error_handler(int,int,char *);

#endif



