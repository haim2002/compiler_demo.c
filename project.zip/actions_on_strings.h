#ifndef ACTIONS_ON_STRINGS_H
#define ACTIONS_ON_STRINGS_H

#include <stdbool.h>


 
bool string_is_empty(char[]);
bool string_is_spaces(char[]);
void remove_trailing_spaces(char*);
bool string_has_space(char[]);
bool string_is_comment(char[]);

#endif
